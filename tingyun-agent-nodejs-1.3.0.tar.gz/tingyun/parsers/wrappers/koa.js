var shimmer = require('../../util/shimmer.js');
var logger = require('../../util/logger.js').child('parsers.wrappers.koa');
var record = require('../../metrics/recorders/generic.js');
var urltils = require('../../util/urltils.js');

function convertAsyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    return Promise.resolve(value).then(function(value) {
                        return step("next", value);
                    }, function(err) {
                        return step("throw", err);
                    });
                }
            }
            return step("next");
        });
    };
}

function checkKoa(Application) {
    try {
        Application();
    } catch (e) {
        return true;
    }
    return false;
}

function indexOf(middleware) {
    for (var i = 0, length = middleware.length; i < length; i++) {
        if (middleware[i].__View) {
            return i;
        }
    }
    return -1;
}

function wrapRender(agent, context, render) {
    return function*(view, locals) {
        var action = agent.tracer.getAction();
        if (agent.config.enabled && action) {
            var segment = createRenderSegment(agent.tracer, record);
            yield render.apply(context, arguments);
            segment.end();
        } else {
            yield render.apply(context, arguments);
        }
    };
}

function wrapNextRender(agent, render) {
    return function() {
        var action = agent.tracer.getAction();
        if (agent.config.enabled && action) {
            var segment = createRenderSegment(agent.tracer, record);
            return render.apply(this, arguments).then(function() {
                segment.end();
            });
        }
        return render.apply(this, arguments);
    }
}

function createRenderSegment(tracer, record) {
    var className = 'Application';
    var name = "Koa/" + className + '/render';
    var segmentInfo = {
        metric_name: name,
        call_url: "",
        call_count: 1,
        class_name: className,
        method_name: "render",
        params: {}
    }
    return tracer.addSegment(segmentInfo, record);
}

function convert(gen) {
    var ref = convertAsyncToGenerator(gen);
    return function(_x, _x2) {
        return ref.apply(this, arguments);
    };
}

function findMatchedRouter(layers) {
    if (layers && layers.length) {
        for (var i = layers.length - 1; i >= 0; i--) {
            if (layers[i].opts && layers[i].opts.end) {
                return layers[i].path;
            }
        }
    }
    return null;
}

function addRouteInterceptor(middleware, agent, isKoaNext) {
    var interceptor = isKoaNext ? convert(function*(ctx, next) {
        yield next();
        var matchedRoute = findMatchedRouter(ctx.matched);
        if (matchedRoute) {
            setRouterName.bind(ctx)(agent, matchedRoute);
        }
    }) : function*(next) {
        yield next;
        if (this._matchedRoute) {
            setRouterName.bind(this)(agent, this._matchedRoute);
        }
    };
    middleware.unshift(interceptor);
}

function setRouterName(agent, matchedRoute) {
    var name = this.method + " " + matchedRoute;
    var action = agent.getAction();
    if (action) {
        var segment = agent.tracer.getSegment();
        segment.parameters = segment.parameters || {};
        var params = this.query;
        urltils.copyParameters(agent.config, params, segment.parameters);
        urltils.copyParameters(agent.config, this.params || {}, segment.parameters);
        if (!action.partialName) {
            action.setPartialName('Koa/' + name.replace(/\//g, "%2F"));    
        }
    }
}

function addViewInterceptor(middleware, index, agent, isKoaNext) {
    var interceptor = isKoaNext ? convert(function*(ctx, next) {
        if (typeof ctx.render === 'function' && !ctx.render.__TY__Wrap) {
            var wrapped = wrapNextRender(agent, ctx.render);
            wrapped.__TY__Wrap = true;
            ctx.render = wrapped;
        }
        yield next();
    }) : function*(next) {
        var render = this.render;
        if (typeof render === 'function' && !render.__TY__Wrap) {
            var wrapped = wrapRender(agent, this, render);
            wrapped.__TY__Wrap = true;
            this.render = wrapped;
        }
        yield next;
    };
    middleware.splice(index, 0, interceptor);
}

function addErrorEvent(agent, isKoaNext) {
    this.on('error', function(error, context) {
        var action = agent.getAction();
        if (action) {
            var status = error.status || 500;
            action.statusCode = status;
            action.exceptions.push(error);
            if (context) {
                var matchedRoute = context._matchedRoute;
                if (matchedRoute) {
                    setRouterName.bind(context)(agent, matchedRoute);
                } else if (isKoaNext && context.matched) {
                    matchedRoute = findMatchedRouter(context.matched);
                }
                if (matchedRoute) {
                    setRouterName.bind(context)(agent, matchedRoute);
                }
            }
        } else {
            agent.errors.add(null, error);
        }
    });
}

module.exports = function initialize(agent, Application) {
    if (!Application || !Application.prototype) {
        return logger.verbose("Application's prototype does not exists.");
    }

    var isKoaNext = checkKoa(Application);

    shimmer.wrapMethodOnce(Application.prototype, 'Application.prototype', 'callback', function(callback) {
        return function() {
            var name = isKoaNext ? 'Koa2' : 'Koa';
            agent.environment.setDispatcher(name);
            agent.environment.setFramework(name);

            addRouteInterceptor(this.middleware, agent, isKoaNext);

            var viewIndex = indexOf(this.middleware);
            if (viewIndex > -1) {
                addViewInterceptor(this.middleware, viewIndex + 1, agent, isKoaNext);
            }

            addErrorEvent.bind(this)(agent, isKoaNext);

            var listener = callback.apply(this, arguments);
            return function _listener(req, res) {
                return listener.apply(this, arguments);
            };
        };
    });
};