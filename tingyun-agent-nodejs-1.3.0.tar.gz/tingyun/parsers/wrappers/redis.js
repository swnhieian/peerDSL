'use strict';

var shimmer = require('../../util/shimmer');
var logger = require('../../util/logger').child('parsers.wrappers.redis');
var record = require('../../metrics/recorders/cache_storage.js')('Redis');
var cmd_map = require('./redis-common/command');
var util = require('../../util/util');

function getAddress(obj) {
    var host = obj.host ? obj.host : (obj.address ? obj.address.split(':')[0] : 'localhost');
    var port = 6379;
    if (obj.port) {
        port = obj.port;
    } else if (obj.address) {
        var addr = obj.address.split(':');
        if (addr.length > 1) {
            port = addr[1];
        }
    }
    return {
        host: host,
        port: port
    };
}

function getMetricName(context, command) {
    var metricName = 'Redis/';
    var address = getAddress(context);
    if (address && address.host && address.port) {
        metricName += (address.host + ':' + address.port) + '/'
    }
    return (metricName + cmd_map.__name_map(command));
}

module.exports = function initialize(agent, redis) {
    var tracer = agent.tracer;
    if (!(redis && redis.RedisClient && redis.RedisClient.prototype)) {
        return;
    }
    shimmer.wrapMethod(redis.RedisClient.prototype, 'redis.RedisClient.prototype', 'send_command', function wrapper(send_command) {
        return tracer.segmentProxy(function wrapped() {
            var action;
            if (!agent.enabled() || !(action = tracer.getAction()) || arguments.length < 1) {
                return send_command.apply(this, arguments);
            }
            var args = tracer.slice(arguments);
            var segmentInfo = {
                metric_name: getMetricName(this, args[0]),
                call_url: "",
                call_count: 1,
                class_name: "redis.RedisClient",
                method_name: 'send_command.' + args[0],
                params: {}
            };
            var segment = tracer.addSegment(segmentInfo, record),
                position = args.length - 1,
                keys = args[1],
                last = args[position];
            if (agent.config.capture_params && keys && typeof keys !== 'function' && agent.config.ignored_params.indexOf('key') === -1) {
                segment.parameters.key = JSON.stringify([keys[0]]);
            }

            function proxy(target) {
                return function cls_finalize() {
                    segment.end();
                    return target.apply(this, arguments);
                };
            }

            if (typeof last === 'function') {
                args[position] = tracer.callbackProxy(proxy(last));
            } else if (Array.isArray(last) && typeof last[last.length - 1] === 'function') {
                var callback = proxy(last[last.length - 1]);
                last[last.length - 1] = tracer.callbackProxy(callback);
            } else {
                args.push(function cb() {
                    segment.end();
                });
            }
            return send_command.apply(this, args);
        });
    });

    shimmer.wrapMethod(redis.RedisClient.prototype, 'redis.RedisClient.prototype', 'internal_send_command', function wrapper(internalSendCommand) {
        return tracer.segmentProxy(function internalSendCommandWrap(cmd) {
            var action;
            if (!agent.enabled() || !(action = tracer.getAction()) || !cmd) {
                return internalSendCommand.apply(this, arguments);
            }
            var segmentInfo = {
                metric_name: getMetricName(this.connection_options, cmd.command),
                call_url: "",
                call_count: 1,
                class_name: "redis.RedisClient",
                method_name: 'internal_send_command.' + cmd.command,
                params: {}
            };
            var segment = tracer.addSegment(segmentInfo, record);
            var callback = cmd.callback;
            if (util.isFunction(callback)) {
                cmd.callback = tracer.callbackProxy(proxy(callback));
            } else {
                cmd.callback = function() {
                    segment.end();
                };
            }

            function proxy(target) {
                return function() {
                    segment.end();
                    return target.apply(this, arguments);
                };
            }

            return internalSendCommand.apply(this, arguments);
        });
    });
};