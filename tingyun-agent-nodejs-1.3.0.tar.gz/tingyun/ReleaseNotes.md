﻿### v1.3.0 (2016-11-15):
* 重构KOA，添加对KOA2框架的支持
* 优化获取应用的依赖模块功能
* 新增tingyun.js配置文件（优先级高于tingyun.json）
* fixed getRedirectHost容错处理
* 支持node-redis v2.6.0+
* 添加thrift跨应用开关设置
* 增加自动嵌码规则，当请求为Ajax请求时不嵌码

### v1.2.0 (2016-09-20):
* WebAction命名
* 修正Metric数据类型
* 修正Metric Id 序列化
* 兼容bluebird v3.0+
* 更新依赖包async-listener(^0.6.0)版本
* 修正MySql模块connection.query()参数处理逻辑
* 修正外部错误计数
* 更新日志输出格式

### v1.1.12 (2016-08-15):
* 修改浏览器嵌码方式，增加混合嵌码

### v1.1.11 (2016-08-10):
* 修正ioredis访问访问后调用栈丢失问题
* 修正express中间件丢失问题,修正log输出内容
* 修正pgsql bug

### v1.1.10 (2016-07-21):
* 修正ioredis访问阻塞

### v1.1.9 (2016-06-01):
* 修正错误数据，增加外部错误信息
* 修改js嵌码位置
* 优化配置文件
* 修改跨应用追踪数据，时间字段数据类型（浮点型->整型）
* 修正当action异常时KOA的路由信息
* 简化sql混淆方法
* 在actionTrace中添加混淆sql和stacktrace数据

### v1.1.8 (2016-05-11):
* 增加thrift跨应用追踪
* 修正错误数据上传内容，错误代码数据类型为整型
* koa框架url聚合

### v1.1.7 (2016-04-18):
* fix bug:ActionTrace上传数据问题
* fix bug:添加错误率数据
* fix bug:thrift数据上传结构
* 支持KOA1框架

### v1.1.6 (2016-04-12):
* 修改redis数据接口格式

### v1.1.5 (2016-04-01):
* 添加对`ioredis`模块的支持

### v1.1.4 (2015-11-13):
* 添加对Oracle社区模块`node-oracle`的支持
* 修改跨应用追踪(2016-01-28)
* 修正hapi框架bug

### v1.1.3 (2015-10-22):
* 添加浏览器嵌码功能

### v1.1.2 (2015-10-20):
* 添加对Oracle官方Nodejs模块oracledb的支持

### v1.1.1 (2015-10-15):
* 修复"最新版Nodejs版本号引起的系统不能正常启动问题" 的bug

### v1.1.0 (2015-08-03):
* 修复"找不到TingYun 对象" 的bug
* 支持跨应用追踪
### v1.0.1 (2015-06-30):
* 移除tingyun.js,增加setup.js, 简化安装过程: npm install 之后运行配置向导: node ./node_modules/tingyun/setup.js,生成tingyun.json配置文件
* 支持windows版本
* thrift 增加对0.9.2多service支持。
* 修复报表中慢应用过程追踪性能数据出现负值的bug
### v1.0.0 (2015-05-27):


* 1.0.0版本发布.
* 支持列表
      web       : http模块
      Framework : express, hapi, restify
      sql       : pg, mysql
      no_sql    : mongodb, redis, memcached, node-cassandra-cql
      External  : http, thrift
* 功能
      1、web性能数据采集
      2、Error Trace信息采集
      3、慢过程追踪信息采集
      4、慢sql追踪信息采集