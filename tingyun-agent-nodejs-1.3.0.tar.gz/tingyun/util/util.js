module.exports = {
    isFunction: function(arg) {
        return typeof arg === 'function';
    },
    extend: function(target, source) {
        if (!source || typeof source !== 'object') {
            return target;
        }
        target = target || {};
        Object.keys(source).forEach(function(key) {
            target[key] = source[key];
        });
        return target;
    },
    isEmptyObject: function(obj) {
        return Object.keys(obj).length === 0 ? true : false;
    }
};