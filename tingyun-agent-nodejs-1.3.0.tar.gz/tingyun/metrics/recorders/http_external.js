'use strict';

function recordExternal(host, library) {
  if (!host) {
    throw new Error('External no host');
  }
  return function cls_recordExternal(segment, scope) {
    var duration    = segment.getDurationInMillis();
    var exclusive   = segment.getExclusiveDurationInMillis();
    var action = segment.trace.action;
    var metricName  = 'External/' + host.replace(/\//g, "%2F") + '/' + library;
    var errorMetricName = metricName;
    if ( segment.parameters.txData && segment.parameters.txData.id ) {
        metricName = [metricName, segment.parameters.txData.id, segment.parameters.txData.action];
    }
    if (scope) {
      action.measure(metricName, scope, duration, exclusive);
    }
    action.measure(metricName,   null, duration, exclusive);
    action.measure(action.isWeb() ? 'External/NULL/AllWeb' : 'External/NULL/AllBackground',   null, duration, exclusive);
    action.measure('External/' + host.replace(/\//g, "%2F") + '/All',   null, duration, exclusive);
    action.measure('External/NULL/All', null, duration, exclusive);
    if (segment.externalResponse) {
            //action.metrics.getMetric('Errors/Count/All').incrementCallCount(1);
            //action.metrics.getMetric(action.isWeb() ? 'Errors/Count/AllWeb' : 'Errors/Count/AllBackground').incrementCallCount(1);
            //action.metrics.getMetric('Errors/Count/' + action.name.replace(/\//g, "%2F")).incrementCallCount(1);
      action.metrics.getMetric('Errors/Count/' + errorMetricName).incrementCallCount(1);
      action.metrics.getMetric('Errors/Type:' + segment.externalResponse.statusCode + '/' + errorMetricName).incrementCallCount(1);
      action.agent.errors.addExternal(segment, errorMetricName, segment.externalResponse.error);
    }
    if ( segment.parameters.txData && segment.parameters.txData.id ) {
      var sec_id = segment.parameters.txData.id.replace(/\//g, "%2F");
      var tokIndex = host.indexOf('://');
      var protocol = (tokIndex > 0)?host.slice(0, tokIndex):'http';
      action.measure('ExternalTransaction/NULL/' + sec_id,   null, duration, exclusive);
      action.measure('ExternalTransaction/' + protocol + '/' + sec_id,   null, duration, exclusive);
      action.measure('ExternalTransaction/' + protocol + ':async/' + sec_id,   null, duration, exclusive);
    }
}
}

module.exports = recordExternal;
